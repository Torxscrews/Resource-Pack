## 使用方法

1 ローカルファイルをプッシュ 

2 アクション Create Archive を実行して release ファイルを作成

3 Download release でファイルをダウンロード

4 GetSHA1 でハッシュを作成

5 resource-pack-sha1に適用
