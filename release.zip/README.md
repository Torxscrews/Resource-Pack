## 使用方法

1 ローカルファイルをプッシュ 

2 `Download release` でファイルをダウンロード

3 `GetSHA1` でハッシュを作成

4 `resource-pack-sha1`に適用
